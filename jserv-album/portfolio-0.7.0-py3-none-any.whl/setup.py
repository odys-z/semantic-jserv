from setuptools import setup, find_packages

# import py2exe
# pip install wheel
# python setup.py bdist_wheel sdist

setup(
    name='portfolio',
    version='0.7.0',
    description='Portfolio Synode Stand Alone Service',
    author='Ody Z',
    zip_safe=False,
    author_email='odys.zhou@gmail.com',
    keywords='Documents File synchronization',
    py_modules=["portfolio-synode", "ui_form", "setup"],
    packages=find_packages(),
    # package_data={'Portfolio.bin': ['../resources/portfolio-srv.exe']},
    # data_files=[('bin', ['bin/jserv-album-0.7.0.jar', '../resources/portfolio-srv.exe'])],
    include_package_data=True,
    
    install_requires=['thread', 'pyside6', 'qrcode', 'anson.py3', 'psutil']
    # classifiers=["Programming Language :: Python :: 3"]
    # console=['installer.py'] # for py2exe
)