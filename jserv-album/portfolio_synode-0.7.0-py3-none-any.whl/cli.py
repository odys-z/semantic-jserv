import sys

from src.installer_api import InstallerCli, ping


def clean(vol: str = None):
    cli = InstallerCli()
    try: cli.loadInitial(vol)
    except FileNotFoundError: pass
    cli.clean_install()


if __name__ == '__main__':

    cmd = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] else 'list'
    arg = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] else None
    arg2= sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else None

    cmds = {
        "list": "list known synodes.",
        "load": "load deploy-path, load configurations",
        "install": "arg[0]: res-path, arg[1] volume-path\n\
        -install the synode service with registration in res-path, volume at volume-path",

        "start": "arg[0]: volume\n\
        - Start the node. Configurations must be setup correctly.\n\
          Wrong configuration may results in fail forever for this node.\n\
          Use test command for test starting.",

        "test": "try bring up the synode without triggering synchronization.",

        "start-web": "start-web <web-port, e.g. 8900> <jserv-port, e.g. 8964>\
        - start the web server, album-web 0.4, at localhost.",

        "sync_in": "arg[0]: volume, arg[1]: number of seconds\n\
        - Update synchronization interval's setting.",

        "showip": "show local ip to be bound",
        "ping": "ping peer-id, peer-jserv, ping configured jserv"
    }

    cli = InstallerCli()
    if cmd == 'list':
        print(cli.list_synodes())
    if cmd == 'load':
        print(cli.loadInitial(arg))

    elif cmd == 'install' or cmd == 'i':
        cli = InstallerCli(arg)
        cli.install(arg, arg2)

    elif cmd == 'clean':
        # cli.loadInitial(arg)
        # cli.clean_install()
        clean(arg)

    elif cmd == 'start':
        cli.loadInitial(arg)
        proc = cli.runjserv()
        try:
            input("Press any key to quit.")
        except KeyboardInterrupt:
            pass
        cli.stop_test(proc)

    elif cmd == 'test':
        cli.loadInitial(arg)
        proc = cli.test_run()
        try:
            input("Press any key to quit.")
        except KeyboardInterrupt:
            pass
        cli.stop_test(proc)

    elif cmd == 'start-web':
        InstallerCli.start_web(arg, arg2)

    elif cmd == 'sync_in':
        cli.loadInitial()
        sins = cli.registry.config.syncIns

    elif cmd == 'showip':
        cli.reportIp()
    elif cmd == 'ping':
        ping(arg, arg2)
    else:
        print('Usage: python3 installer-cli.py cmd.\nCommands:')
        for c in cmds:
            print(f'{c}\t: {cmds[c]}')
